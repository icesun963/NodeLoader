git add .
git commit -a -m 'change'
git push origin master
